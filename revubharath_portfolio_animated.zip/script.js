
document.getElementById("toggleBtn").addEventListener("click", function() {
  document.body.classList.toggle("light");
});
